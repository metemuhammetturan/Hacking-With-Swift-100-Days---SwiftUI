import UIKit





// Shopping Chart


protocol ShoppingChart {
    var product_name: String { get }
    var product_price: Int { get }
    
    func calculate_total_cost() -> Int
    func add_product(name: String, price: Int)
    func subtract_product()
}

extension ShoppingChart {
    func calculate_total_cost() -> Int {
        return product_price
    }
}

struct GroceryBasket: ShoppingChart {
    var products: [(name: String, price: Int)] = []

    var product_name: String {
        return products.last?.name ?? ""
    }

    var product_price: Int {
        return products.last?.price ?? 0
    }

    func add_product(name: String, price: Int) {
        products.append((name: name, price: price))
        print("\(name) added to the basket.")
    }

    mutating func subtract_product() {
        if let lastProduct = products.popLast() {
            print("\(lastProduct.name) removed from the basket.")
        } else {
            print("Basket is empty. Cannot remove any product.")
        }
    }
    
    func calculate_total_cost() -> Int {
        let totalCost = products.reduce(0) { $0 + $1.price }
        print("Total basket price: \(totalCost)")
        return totalCost
    }
}

struct ElectronicsBasket: ShoppingChart {
    var products: [(name: String, price: Int)] = []

    var product_name: String {
        return products.last?.name ?? ""
    }

    var product_price: Int {
        return products.last?.price ?? 0
    }

    func add_product(name: String, price: Int) {
        products.append((name: name, price: price))
        print("\(name) added to the basket.")
    }

    mutating func subtract_product() {
        if let lastProduct = products.popLast() {
            print("\(lastProduct.name) removed from the basket.")
        } else {
            print("Basket is empty. Cannot remove any product.")
        }
    }
    
    func calculate_total_cost() -> Int {
        let totalCost = products.reduce(0) { $0 + $1.price }
        print("Total basket price: \(totalCost)")
        return totalCost
    }
}

// Example Usage:

var groceryBasket = GroceryBasket()
groceryBasket.add_product(name: "Apple", price: 2)
groceryBasket.add_product(name: "Milk", price: 3)
groceryBasket.calculate_total_cost()

var electronicsBasket = ElectronicsBasket()
electronicsBasket.add_product(name: "Laptop", price: 1200)
electronicsBasket.add_product(name: "Headphones", price: 100)
electronicsBasket.calculate_total_cost()
electronicsBasket.subtract_product()
electronicsBasket.calculate_total_cost()

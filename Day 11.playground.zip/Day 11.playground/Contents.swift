import UIKit

//Example for Car Store

struct InfoAboutCar {
    
    let model: String
    let number_of_seats: Int
    static var current_gear: Int = 1 // Başlangıç değeri atanmalı
    
    mutating func gear_up(gear_new: Int) {
        
        if gear_new > 0 {
            let new_gear = InfoAboutCar.current_gear + gear_new
            
            if new_gear > 10 {
                print("Gear shouldn't be more than 10! Please decrease the amount of gear to be increased!")
            } else {
                InfoAboutCar.current_gear = new_gear
                print("Gear increased to \(InfoAboutCar.current_gear)")
            }
        } else if gear_new < 0 {
            let new_gear = InfoAboutCar.current_gear + gear_new
            
            if new_gear < 1 {
                print("Gear shouldn't be less than 1! Please increase the amount of gear to be decreased!")
            } else {
                InfoAboutCar.current_gear = new_gear
                print("Gear decreased to \(InfoAboutCar.current_gear)")
            }
        }
    }
}

// Örnek oluşturalım
var carInfo = InfoAboutCar(model: "Example Model", number_of_seats: 5)

// Metodu çağıralım
carInfo.gear_up(gear_new: 2)

import UIKit



// Closures Challenge #1

let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

let filteredNumbers = luckyNumbers.filter{!$0.isMultiple(of: 2)}

let sortedNumbers = filteredNumbers.sorted()

let formattedStrings = sortedNumbers.map {"\($0) is a lucky number."}

formattedStrings.forEach {print($0)}


// Closures Challenge #2

var numbers = [2,3,4,5,7,21,43]

let multiplied_with_two = numbers.map{$0 * 2}

multiplied_with_two.forEach{ print($0) }

// Closure Challenge #3

var numbers_2 = [1,2,3,4,5,6,7,8,9,10]

var filtered_by_is_muliple_of_two = numbers_2.filter{$0.isMultiple(of: 2)}

var added_3 = numbers_2.map{$0 + 3}

print("Original numbers are: ")
numbers_2.forEach{print($0)}

print("Muliplied with 2 numbers are: ")
filtered_by_is_muliple_of_two.forEach{print($0)}

print("Muliplied with 2 and added 3 numbers are: ")
added_3.forEach{print($0)}




import UIKit

// Classes


class Musicians{
    var name:String
    var age:Int
    var instrument:String
    
    init(nameInit:String,ageInit:Int,instrumentInit:String)
    {
        self.name = nameInit
        self.age = ageInit
        self.instrument = instrumentInit
    }
    
    func sing()
    {
        print("nothing else matters")
    }
    
}

var mete = Musicians(nameInit: "Mete", ageInit: 19, instrumentInit: "Guitar")

print(mete.age)


// Checkpoint for day 12


class Animal {
    var legs: Int
    
    init(legs: Int) {
        self.legs = legs
    }
}

class Dog: Animal {
    class Corgi: Dog {
        override init(legs: Int) {
            super.init(legs: legs)
        }
        
        func speak() {
            print("I am Corgi")
        }
    }
    
    class Poodle: Dog {
        override init(legs: Int) {
            super.init(legs: legs)
        }
        
        func speak() {
            print("I am Poodle")
        }
    }
}

class Cat: Animal {
    class Persian: Cat {
        override init(legs: Int) {
            super.init(legs: legs)
        }
        
        func speak() {
            print("I am Persian")
        }
    }
    
    class Lion: Cat {
        override init(legs: Int) {
            super.init(legs: legs)
        }
        
        func speak() {
            print("I am Lion")
        }
    }
}

let corgi = Dog.Corgi(legs: 4)
corgi.speak()

let persianCat = Cat.Persian(legs: 4)
persianCat.speak()

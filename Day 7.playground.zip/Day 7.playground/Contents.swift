import UIKit



        // ------------- Functions ------------- //


// Creating a function


func showWelcome() {

    print("Hello!")
    print("Welcome to my app!")
    
}


// Simple Times Table App


func printTimesTable(number: Int)
{
    
    for i in 1...10
    {
        print("\(i) * \(number) = \(i*number)")
    }
    
}

printTimesTable(number: 12)

print("---------------------------------------")

// Simple Times Table App V2


func printTimesTable(number: Int, end: Int)
{
    
    for i in 1...end
    {
        print("\(i) * \(number) = \(i*number)")
    }
    
}

printTimesTable(number: 12, end: 5)


// More complex example


func areLettersIdentical(string1: String, string2: String) -> Bool 
{
    
    let first = string1.sorted()
    let second = string2.sorted()
    
    return first == second
    
}


// Rolling Dice

func rollDice() -> Int
{
    Int.random(in: 1...6)
}

rollDice()

// Pythagoras

func pythagoras(first_number: Double, second_number: Double) -> Double 
{
    
    let calculating = first_number * first_number + second_number * second_number
    let root = sqrt(calculating)
    
    return(root)
    
}

pythagoras(first_number: 3, second_number: 4)


sqrt(5)





















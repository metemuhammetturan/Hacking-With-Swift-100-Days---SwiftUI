import UIKit

// --------------- LOOPS --------------- //

var myNumber = 1

 myNumber += 1

var number = 1

// WHILE //

while number < 10 {
    number += 1
}

// FOR //

var my_fruits = ["apple","banana","strawberry"]

for fruit in my_fruits {
    print(fruit)
}
        
        
// Fizz Buzz Game


for fizz_buzz in 1..<100 {
    
    if ((fizz_buzz % 15) == 0){
        
        print("\(fizz_buzz) = Fizz Buzz")
        
    } else if ((fizz_buzz % 3) == 0) {
        
        print("\(fizz_buzz) = Fizz")
        
    } else if ((fizz_buzz % 5) == 0) {
        
        print("\(fizz_buzz) = Buzz")
        
    }
    
}



import UIKit

// Creating Struct

struct Album
{

    let title: String
    let artist: String
    let year: Int
    
    func printSummary()
    {
        print("\(title) \(year) by \(artist)")
    }
    
}



let tuz_buz = Album(title: "Tuz Kral", artist: "Cem Adrian", year: 2013)

print(tuz_buz.title)



// Bank Account



struct BankAccount
{
    
    var customer_name: String
    var customer_surname: String
    var customer_balance: Int
    
    mutating func adding_withdrawing_money(amount: Int)
    {
        
        if (amount<0){
            
            customer_balance -= amount
            
        }
        
        if (amount>0){
            customer_balance += amount
        }
    }
}

    var my_account = BankAccount(customer_name: "Mete", customer_surname: "Turan", customer_balance: 1000)
        
    my_account.adding_withdrawing_money(amount: 2500)
    print("New account balance is: \(my_account.customer_balance) TL")

    my_account.adding_withdrawing_money(amount: -500)
    print("New account balance is: \(my_account.customer_balance) TL")


// SHOPPING CART







struct ShoppingCart {
    
    struct Product {
        let product_name: String
        let product_price: Int
        var product_currently_quantity: Int
    }
    
    var in_shopping_cart_products = [Product]()
    

    func show_in_cart() {
        
        print(" --- Products in your cart ---")
        
        for product in in_shopping_cart_products {
            
            print("Name: \(product.product_name), Quantity: \(product.product_currently_quantity), Price: \(product.product_price) TL")
            
        }
        
    }

    mutating func addProduct(product: Product, quantity: Int) {
        // When adding a product to the cart, if the product has been added before, increase its quantity, otherwise add it as a new product
        if let existingProductIndex = in_shopping_cart_products.firstIndex(where: { $0.product_name == product.product_name }) {
            in_shopping_cart_products[existingProductIndex].product_currently_quantity += quantity
        } else {
            var newProduct = product
            newProduct.product_currently_quantity = quantity
            in_shopping_cart_products.append(newProduct)
        }
    }
    
    mutating func removeProduct(productName: String) {
        // When removing items from cart, if quantity is more than 1 item, reduce quantity, otherwise remove item completely
        
        if let existingProductIndex = in_shopping_cart_products.firstIndex(where: { $0.product_name == productName }) {
            if in_shopping_cart_products[existingProductIndex].product_currently_quantity > 1 {
                in_shopping_cart_products[existingProductIndex].product_currently_quantity -= 1
            } else {
                in_shopping_cart_products.remove(at: existingProductIndex)
            }
        }
    }
    
    var totalAmount: Int {
        // Calculates the total amount of the cart
        return in_shopping_cart_products.reduce(0) { $0 + ($1.product_price * $1.product_currently_quantity) }
    }
}



var shoppingCart = ShoppingCart()

let product1 = ShoppingCart.Product(product_name: "iPhone 11", product_price: 23999, product_currently_quantity: 1)
let product2 = ShoppingCart.Product(product_name: "iPhone 12", product_price: 25849, product_currently_quantity: 2)
let product3 = ShoppingCart.Product(product_name: "iPhone 13", product_price: 37499, product_currently_quantity: 2)


shoppingCart.addProduct(product: product1, quantity: 1)
shoppingCart.addProduct(product: product2, quantity: 1)

print("Total Amount: \(shoppingCart.totalAmount) TL")

shoppingCart.removeProduct(productName: "iPhone 11")

print("Total Amount after removing iPhone 11: \(shoppingCart.totalAmount) TL")

shoppingCart.show_in_cart()

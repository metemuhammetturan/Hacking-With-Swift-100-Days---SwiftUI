import UIKit




// SQRT APP


func sqrtApp(number: Int) {
    
    if number < 1 || number > 10000 {
        print("Out of bounds! Please enter a value between 1 to 10,000!")
    } else {
        var hasRoot = false

        for i in 1...number {
            if i * i == number {
                print("\(number)'s square root is = \(i)")
                hasRoot = true
                break
            }
        }

        if !hasRoot {
            print("\(number) has no square root.")
        }
    }
}

sqrtApp(number: 14)

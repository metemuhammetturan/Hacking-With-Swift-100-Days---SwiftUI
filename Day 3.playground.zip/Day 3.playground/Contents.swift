import UIKit

// ----------------------- ARRAYS ----------------------- //

var singers = ["Cem Adrian", "Sezen Aksu", "Haluk Levent"]
print(singers[0])








var personalInfo = ["Mete", "Turan", "19"]

print("Name: \(personalInfo[0])")
print("Surname: \(personalInfo[1])")
print("Age: \(personalInfo[2])")


// But the arrays could be cause for mistakes because of sorting by index. What i mean let me explain if we remove index 1 after this time index 1 will be 19 so age. But we tried to write surname with index 1. So what happened? The surname is happened 19 this is a problem. Because it could be password too.


// ----------------------- Dictionaries ----------------------- //


let employee = [
    "name": "Taylor Swift",
    "job": "Singer",
    "location": "Nashville"
]

print(employee["name"])
print(employee["job"])
print(employee["location"])



// ----------------------- Set ----------------------- //

var mySet: Set = [1,2,3,4,5,2,2,1,2,3,2,]
print(mySet)

var myUniqeArray = Set(mySet)

// ----------------------- Enum ----------------------- //

enum Weekday {
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
}

enum Weekday2 {
    case monday, tuesday, wednesday, thursday, friday
}

enum Months {
    case january, february, march, april, may, june, july, august, september, october, december, november
}

print(Months.january)

// Enums are used to make code more understandable and manageable.

import UIKit



//Properties for Estate App

/*
 
 - A property storing how many rooms it has
 - A property storing the cost as an integer
 - A property storing the name of the estate agent responsible for selling the building
 - A method for printing the sales summary of the building describing what it is along with its other properties
    (Sales Summary)
 
 */

protocol Properties_of_House {
    var rooms: Int { get }
    var cost_of_building: Int { get }
    var estate_agents_name: String { get }
    func print_buildings_summary()
}

extension Properties_of_House {
    func print_buildings_summary() {
        print("""
            --- Properties of this building ---
            Rooms Number: \(rooms)
            Total Cost of Building: \(cost_of_building)
            Estate Agents Name: \(estate_agents_name)
            """)
    }
}

struct House: Properties_of_House {
    var rooms: Int
    var cost_of_building: Int
    var estate_agents_name: String
}

let myHouse = House(rooms: 3, cost_of_building: 500000, estate_agents_name: "Mete Turan")

myHouse.print_buildings_summary()

